mainClass: 'mfp-with-zoom',
zoom: {
  enabled: true,
  duration: 300,
  easing: 'ease-in-out'
}